// ─────────────────────────────────────────────────────────────────────────────
//  怠竜 VidSnatcher · background.js · v1.1.0
//  by The Lazy Dragon · github.com/The-Lazy-Dragon
// ─────────────────────────────────────────────────────────────────────────────

// ─── Blacklist ──────────────────────────────────────────────────────────────
// We don't intercept these. Big companies, big lawyers.
const BLACKLISTED_DOMAINS = [
  'netflix.com','primevideo.com','amazon.com',
  'disneyplus.com','hulu.com','max.com','hbomax.com',
  'peacocktv.com','paramountplus.com','appletv.apple.com',
  'crunchyroll.com','funimation.com','mubi.com',
  'curiositystream.com','discoveryplus.com',
  'espnplus.com','starz.com','showtime.com','mgmplus.com',
  'hotstar.com','jiocinema.com','sonyliv.com','zee5.com',
  'tv.apple.com','tv2.no','nowtv.com','britbox.com',
  'acorn.tv','shudder.com','criterion.com'
];

function isBlacklistedUrl(url) {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    return BLACKLISTED_DOMAINS.some(d => host === d || host.endsWith('.' + d));
  } catch { return false; }
}

// ─── Type detection ─────────────────────────────────────────────────────────
const VIDEO_EXTS   = ['.mp4','.webm','.mkv','.avi','.mov','.flv','.m4v','.ogv'];
const STREAM_EXTS  = ['.m3u8','.m3u','.mpd'];
const SEGMENT_EXTS = ['.ts','.m4s','.aac'];
const VIDEO_MIMES  = [
  'video/mp4','video/webm','video/ogg','video/x-matroska',
  'video/quicktime','video/mpeg','video/x-flv',
  'application/x-mpegurl','application/vnd.apple.mpegurl',
  'application/dash+xml'
];

function getPathLower(url) {
  try { return new URL(url).pathname.toLowerCase(); }
  catch { return (url || '').toLowerCase(); }
}

function classifyUrl(url) {
  if (!url || url.startsWith('mediasource://') || url.startsWith('blob:')) return null;
  const p = getPathLower(url).split('?')[0];
  if (STREAM_EXTS.some(e => p.endsWith(e)))  return 'stream';
  if (VIDEO_EXTS.some(e => p.endsWith(e)))   return 'direct';
  if (SEGMENT_EXTS.some(e => p.endsWith(e))) return 'segment';
  return null;
}

function getType(url) {
  const p = getPathLower(url).split('?')[0];
  if (p.endsWith('.m3u8') || p.endsWith('.m3u')) return 'HLS';
  if (p.endsWith('.mpd')) return 'DASH';
  if (p.endsWith('.ts') || p.endsWith('.m4s')) return 'TS Segment';
  return (p.split('.').pop() || 'VIDEO').toUpperCase();
}

function getFilename(url) {
  try {
    const n = new URL(url).pathname.split('/').pop().split('?')[0];
    return n.length > 2 ? n : 'video';
  } catch { return 'video'; }
}

// ─── State (with session persistence) ───────────────────────────────────────
// MV3 service workers sleep. State that lives only in memory disappears when
// they wake up again. Anything that should survive a SW restart goes in
// chrome.storage.session.
const detectedVideos  = {};   // tabId → { _tabUrl, [url]: video }
const activeDownloads = {};   // reqId → { reqId, percent, stage, ... }
let restoredFromSession = false;

async function restoreSession() {
  if (restoredFromSession) return;
  restoredFromSession = true;
  try {
    const data = await chrome.storage.session.get(['detectedVideos', 'activeDownloads']);
    if (data.detectedVideos) Object.assign(detectedVideos, data.detectedVideos);
    if (data.activeDownloads) Object.assign(activeDownloads, data.activeDownloads);
  } catch (e) { /* fresh session */ }
}

async function persistDetected() {
  try { await chrome.storage.session.set({ detectedVideos }); } catch { /* meh */ }
}
async function persistDownloads() {
  try { await chrome.storage.session.set({ activeDownloads }); } catch { /* meh */ }
}

// ─── Badge ──────────────────────────────────────────────────────────────────
// Per-tab: red count of detected videos.
// Global override: purple % while a stream download is running.
let downloadBadgeTimer = null;

function paintVideoBadge(tabId) {
  const bucket = detectedVideos[tabId] || {};
  const count = Object.keys(bucket).filter(k => k !== '_tabUrl').length;
  // Don't override the global download badge.
  if (Object.keys(activeDownloads).length > 0) return;
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : '', tabId }).catch(()=>{});
  chrome.action.setBadgeBackgroundColor({ color: '#ff153f', tabId }).catch(()=>{});
}

function startDownloadBadge() {
  if (downloadBadgeTimer) return;
  const tick = () => {
    const vals = Object.values(activeDownloads).filter(d => !d.done);
    if (!vals.length) { stopDownloadBadge(); return; }
    const avg = Math.round(vals.reduce((a, b) => a + (b.percent || 0), 0) / vals.length);
    chrome.action.setBadgeText({ text: `${avg}%` }).catch(()=>{});
    chrome.action.setBadgeBackgroundColor({ color: '#8e44ad' }).catch(()=>{});
  };
  tick();
  downloadBadgeTimer = setInterval(tick, 700);
}

function stopDownloadBadge() {
  if (downloadBadgeTimer) {
    clearInterval(downloadBadgeTimer);
    downloadBadgeTimer = null;
  }
  // Clear the global badge, then restore per-tab badges.
  chrome.action.setBadgeText({ text: '' }).catch(()=>{});
  chrome.tabs.query({}, tabs => tabs.forEach(t => paintVideoBadge(t.id)));
}

// ─── Network intercept ──────────────────────────────────────────────────────
chrome.webRequest.onResponseStarted.addListener(
  async (details) => {
    await restoreSession();
    const { url, tabId, responseHeaders } = details;
    if (tabId < 0) return;

    const ct = (responseHeaders || [])
      .find(h => h.name.toLowerCase() === 'content-type')?.value || '';
    const kind = classifyUrl(url);
    const isMime = VIDEO_MIMES.some(m => ct.toLowerCase().includes(m));

    if ((!kind && !isMime) || kind === 'segment') return;

    if (!detectedVideos[tabId]) detectedVideos[tabId] = {};
    if (isBlacklistedUrl(detectedVideos[tabId]._tabUrl || '')) return;
    if (detectedVideos[tabId][url]) return;

    const type = getType(url);
    detectedVideos[tabId][url] = {
      url, type,
      isStream: type === 'HLS' || type === 'DASH',
      contentType: ct,
      filename: getFilename(url),
      source: 'network',
      timestamp: Date.now()
    };
    paintVideoBadge(tabId);
    persistDetected();
    chrome.runtime.sendMessage({
      action: 'videoFound', tabId, video: detectedVideos[tabId][url]
    }).catch(()=>{});
  },
  { urls: ['<all_urls>'] },
  ['responseHeaders']
);

// ─── Tab lifecycle ──────────────────────────────────────────────────────────
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && tab.url) {
    // Fresh navigation — wipe the bucket but remember the new URL.
    detectedVideos[tabId] = { _tabUrl: tab.url };
    paintVideoBadge(tabId);
    persistDetected();
  } else if (changeInfo.url) {
    if (!detectedVideos[tabId]) detectedVideos[tabId] = {};
    detectedVideos[tabId]._tabUrl = changeInfo.url;
    persistDetected();
  }
});

chrome.tabs.onRemoved.addListener(tabId => {
  delete detectedVideos[tabId];
  persistDetected();
});

// ─── Offscreen lifecycle ────────────────────────────────────────────────────
let offscreenReadyPromise = null;

async function ensureOffscreen() {
  if (offscreenReadyPromise) return offscreenReadyPromise;
  offscreenReadyPromise = (async () => {
    try {
      const exists = await chrome.offscreen.hasDocument();
      if (!exists) {
        await chrome.offscreen.createDocument({
          url: 'offscreen.html',
          reasons: ['BLOBS'],
          justification: 'HLS/DASH segment download, AES-128 decryption, and Blob stitching'
        });
      }
    } catch (e) {
      console.error('[VidSnatcher] offscreen creation failed:', e);
      offscreenReadyPromise = null; // allow retry
      throw e;
    }
  })();
  return offscreenReadyPromise;
}

// ─── Messages ───────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Wrap async paths so sendResponse stays valid.
  (async () => {
    await restoreSession();

    if (msg.action === 'getVideos') {
      const bucket = detectedVideos[msg.tabId] || {};
      const videos = Object.entries(bucket)
        .filter(([k]) => k !== '_tabUrl')
        .map(([, v]) => v);
      sendResponse({ videos });
      return;
    }

    if (msg.action === 'domVideos') {
      const tabId = sender.tab?.id;
      if (!tabId || tabId < 0) { sendResponse({ ok: false }); return; }
      if (!detectedVideos[tabId]) detectedVideos[tabId] = {};
      if (isBlacklistedUrl(detectedVideos[tabId]._tabUrl || '')) {
        sendResponse({ ok: false, blacklisted: true });
        return;
      }
      (msg.videos || []).forEach(v => {
        if (!v || !v.url) return;
        // Block fake mediasource:// URLs from being treated as downloadable.
        if (v.url.startsWith('mediasource://')) return;
        if (!detectedVideos[tabId][v.url]) detectedVideos[tabId][v.url] = v;
      });
      paintVideoBadge(tabId);
      persistDetected();
      sendResponse({ ok: true });
      return;
    }

    if (msg.action === 'download') {
      chrome.downloads.download(
        { url: msg.url, filename: msg.filename, saveAs: true },
        id => sendResponse({ downloadId: id, error: chrome.runtime.lastError?.message })
      );
      return; // async sendResponse — keep channel open below
    }

    if (msg.action === 'downloadStream') {
      const { reqId, url, filename, streamType } = msg;
      activeDownloads[reqId] = {
        reqId, url, filename, streamType,
        percent: 0, stage: 'Queued', done: false
      };
      persistDownloads();
      startDownloadBadge();
      try {
        await ensureOffscreen();
        chrome.runtime.sendMessage({
          action: 'offscreen_startDownload', reqId, url, filename, streamType
        }).catch(()=>{});
        sendResponse({ ok: true });
      } catch (e) {
        activeDownloads[reqId] = {
          ...activeDownloads[reqId],
          percent: 0, stage: '',
          error: `Offscreen failed: ${e.message}`, done: true
        };
        persistDownloads();
        chrome.runtime.sendMessage({
          action: 'streamProgress', reqId, percent: 0, stage: '',
          error: `Offscreen failed: ${e.message}`, done: true
        }).catch(()=>{});
        sendResponse({ ok: false, error: e.message });
      }
      return;
    }

    if (msg.action === 'cancelDownload') {
      const { reqId } = msg;
      if (activeDownloads[reqId]) {
        activeDownloads[reqId].cancelled = true;
        activeDownloads[reqId].done = true;
      }
      persistDownloads();
      try { await ensureOffscreen(); } catch {}
      chrome.runtime.sendMessage({ action: 'offscreen_cancel', reqId }).catch(()=>{});
      chrome.runtime.sendMessage({
        action: 'streamProgress', reqId, percent: 0, stage: '',
        error: 'Cancelled by user.', done: true, cancelled: true
      }).catch(()=>{});
      setTimeout(() => {
        delete activeDownloads[reqId];
        persistDownloads();
        if (!Object.keys(activeDownloads).length) stopDownloadBadge();
      }, 1000);
      sendResponse({ ok: true });
      return;
    }

    if (msg.action === 'triggerDownload') {
      const { blobUrl, filename, reqId } = msg;
      chrome.downloads.download({ url: blobUrl, filename, saveAs: true }, (downloadId) => {
        if (chrome.runtime.lastError) {
          const errMsg = chrome.runtime.lastError.message;
          chrome.runtime.sendMessage({
            action: 'streamProgress', reqId, percent: 0, stage: '',
            error: `Download failed: ${errMsg}`, done: true
          }).catch(()=>{});
        }
      });
      sendResponse({ ok: true });
      return;
    }

    if (msg.action === 'progressUpdate') {
      const { reqId, percent, stage, error, done, cancelled } = msg;
      if (activeDownloads[reqId]) {
        activeDownloads[reqId] = {
          ...activeDownloads[reqId],
          percent: percent || 0, stage, error,
          done: !!done, cancelled: !!cancelled
        };
      }
      persistDownloads();
      if (done || error) {
        setTimeout(() => {
          delete activeDownloads[reqId];
          persistDownloads();
          if (!Object.keys(activeDownloads).length) stopDownloadBadge();
        }, 5000);
      }
      chrome.runtime.sendMessage({
        action: 'streamProgress', reqId, percent, stage, error, done, cancelled
      }).catch(()=>{});
      sendResponse({ ok: true });
      return;
    }

    if (msg.action === 'getActiveDownloads') {
      sendResponse({ downloads: activeDownloads });
      return;
    }

    if (msg.action === 'clearVideos') {
      const tabId = msg.tabId;
      const prevUrl = detectedVideos[tabId]?._tabUrl;
      detectedVideos[tabId] = prevUrl ? { _tabUrl: prevUrl } : {};
      paintVideoBadge(tabId);
      persistDetected();
      sendResponse({ ok: true });
      return;
    }

    sendResponse({ ok: false, error: 'Unknown action' });
  })();

  return true; // async response on every path
});

// On wake-up, restore state so the popup sees what's there.
restoreSession();
