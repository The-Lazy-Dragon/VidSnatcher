// ─────────────────────────────────────────────────────────────────────────────
//  怠竜 VidSnatcher · popup.js · v1.1.0
//  by The Lazy Dragon · github.com/The-Lazy-Dragon
// ─────────────────────────────────────────────────────────────────────────────

let currentTab    = null;
let allVideos     = {};
let activeFilter  = 'all';
let liveDownloads = {};

// ─── Utils ───────────────────────────────────────────────────────────────────
function getFilename(url) {
  try { const n = new URL(url).pathname.split('/').pop().split('?')[0]; return n.length > 2 ? n : 'video'; }
  catch { return 'video'; }
}
function getHost(url) { try { return new URL(url).hostname; } catch { return url; } }
function fmtDur(s) { if (!s || isNaN(s)) return null; return `${Math.floor(s/60)}:${Math.floor(s%60).toString().padStart(2,'0')}`; }
function mergeVideos(videos) { (videos || []).forEach(v => { if (v?.url && !allVideos[v.url]) allVideos[v.url] = v; }); }

// ─── Blacklist (mirrored from background for the warning banner) ────────────
const BLACKLIST = [
  'netflix.com','primevideo.com','amazon.com','disneyplus.com','hulu.com',
  'max.com','hbomax.com','peacocktv.com','paramountplus.com','appletv.apple.com',
  'crunchyroll.com','funimation.com','mubi.com','curiositystream.com',
  'discoveryplus.com','espnplus.com','starz.com','showtime.com','mgmplus.com',
  'hotstar.com','jiocinema.com','sonyliv.com','zee5.com','tv.apple.com',
  'nowtv.com','britbox.com','acorn.tv','shudder.com'
];
function isBlacklisted(url) {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    return BLACKLIST.some(d => host === d || host.endsWith('.' + d));
  } catch { return false; }
}

// ─── Blacklisted-tab banner ─────────────────────────────────────────────────
function renderBlacklistWarning() {
  document.getElementById('bl-warning')?.remove();
  if (!currentTab || !isBlacklisted(currentTab.url)) return;
  const host = getHost(currentTab.url);
  const el = document.createElement('div');
  el.id = 'bl-warning';
  el.style.cssText = `
    padding: 10px 14px;
    background: #1a0a08;
    border-top: 1px solid #712637;
    border-bottom: 1px solid #712637;
    font-size: 11px;
    color: #ff6b6b;
    line-height: 1.5;
    flex-shrink: 0;
  `;
  el.innerHTML = `
    <div style="font-weight:700;color:#ff153f;text-shadow:0 0 6px rgba(255,21,63,0.4);margin-bottom:3px">
      🚫 Blocked — ${host}
    </div>
    <div style="color:#712637">
      This site is on the blacklist. VidSnatcher won't intercept or download from paid streaming platforms.
      That's on purpose.
    </div>
  `;
  document.querySelector('.tabs').insertAdjacentElement('afterend', el);
}

// ─── Download banner ────────────────────────────────────────────────────────
function renderDownloadBanner() {
  const banner = document.getElementById('dl-banner');
  const downloads = Object.values(liveDownloads);
  if (!downloads.length) { banner.innerHTML = ''; return; }

  banner.innerHTML = downloads.map(d => {
    const isErr  = !!d.error;
    const isDone = d.done && !d.error && !d.cancelled;
    const isCan  = !!d.cancelled;
    const pct    = d.percent || 0;
    const stateClass = isErr ? 'error' : isDone ? 'done' : isCan ? 'cancelled' : '';
    const pctClass   = isErr ? 'error' : isDone ? 'done' : '';
    const barClass   = isErr ? 'error' : isDone ? 'done' : 'active';
    const stageClass = isErr ? 'error' : isDone ? 'done' : '';

    return `
      <div class="dl-item ${stateClass}">
        <div class="dl-top">
          <div class="dl-name" title="${d.filename || ''}">${d.filename || 'stream'}</div>
          <div class="dl-pct ${pctClass}">${isErr ? 'ERR' : isCan ? 'CANCELLED' : isDone ? 'DONE' : pct + '%'}</div>
          ${(!isDone && !isErr && !isCan) ? `<button class="dl-cancel" data-reqid="${d.reqId}">✕ Cancel</button>` : ''}
        </div>
        <div class="dl-bar-bg">
          <div class="dl-bar-fill ${barClass}" style="width:${pct}%"></div>
        </div>
        <div class="dl-stage ${stageClass}">
          ${isErr ? '✗ ' + d.error : isCan ? 'Cancelled by user.' : isDone ? '✓ ' + d.stage : d.stage || 'Working...'}
        </div>
      </div>`;
  }).join('');

  banner.querySelectorAll('.dl-cancel').forEach(btn => {
    btn.addEventListener('click', () => {
      const reqId = btn.dataset.reqid;
      chrome.runtime.sendMessage({ action: 'cancelDownload', reqId });
      if (liveDownloads[reqId]) {
        liveDownloads[reqId].cancelled = true;
        liveDownloads[reqId].done = true;
      }
      renderDownloadBanner();
    });
  });
}

// ─── Video cards ────────────────────────────────────────────────────────────
function render() {
  const list  = document.getElementById('video-list');
  const badge = document.getElementById('count-badge');

  let videos = Object.values(allVideos);
  if (activeFilter === 'direct') videos = videos.filter(v => !v.isStream && !v.isBlob);
  if (activeFilter === 'stream') videos = videos.filter(v => v.isStream || v.isBlob);
  videos.sort((a, b) => b.timestamp - a.timestamp);

  const total = Object.keys(allVideos).length;
  badge.textContent = total;
  badge.className = 'count-badge' + (total === 0 ? ' zero' : '');

  renderDownloadBanner();

  if (!videos.length) {
    list.innerHTML = `<div class="empty-state">
      <div class="icon">${total > 0 ? '🔍' : '📡'}</div>
      <div class="title">— ${total > 0 ? 'NO MATCHES' : 'LISTENING'} —</div>
      <div class="sub">${total > 0 ? 'Switch to All tab.' : 'Play a video on this page,\nthen hit SCAN.'}</div>
    </div>`;
    return;
  }

  list.innerHTML = videos.map(v => {
    const isStream  = !!v.isStream;
    const isBlob    = !!v.isBlob || v.source === 'blob' || v.source === 'mediasource';
    const typeClass = isBlob ? 'blob' : isStream ? 'hls' : '';
    const dlLabel   = isBlob ? '⚠ Blob (no download)' : isStream ? '⬇ Stitch & Download' : '⬇ Download';
    const dotClass  = v.source || 'dom';

    const meta = [];
    if (v.resolution) meta.push(`📐 ${v.resolution}`);
    if (v.duration)   meta.push(`⏱ ${fmtDur(v.duration)}`);
    meta.push(`📂 ${(v.source || '?').toUpperCase()}`);
    if (v.contentType) meta.push(`📄 ${v.contentType.split(';')[0]}`);

    return `<div class="video-card">
      <div class="card-top">
        <div class="source-dot ${dotClass}"></div>
        <div class="filename">${v.filename || getFilename(v.url)}</div>
        <div class="type-badge ${typeClass}">${v.type || 'VIDEO'}</div>
      </div>
      <div class="url-display" title="${v.url}">${v.url}</div>
      ${meta.length ? `<div class="meta">${meta.map(m => `<div class="meta-item">${m}</div>`).join('')}</div>` : ''}
      ${v.note ? `<div class="note-box">⚠ ${v.note}</div>` : ''}
      <div class="card-actions">
        <button class="btn-dl ${isStream ? 'stream' : ''}"
          data-url="${encodeURIComponent(v.url)}"
          data-filename="${encodeURIComponent(v.filename || getFilename(v.url))}"
          data-stream="${isStream}" data-type="${v.type || ''}"
          ${isBlob ? 'disabled' : ''}>
          ${dlLabel}
        </button>
        <button class="btn-copy" data-url="${encodeURIComponent(v.url)}">Copy</button>
      </div>
    </div>`;
  }).join('');

  list.querySelectorAll('.btn-dl:not([disabled])').forEach(btn => {
    btn.addEventListener('click', () => {
      const url      = decodeURIComponent(btn.dataset.url);
      const filename = decodeURIComponent(btn.dataset.filename);
      const isStream = btn.dataset.stream === 'true';
      const type     = btn.dataset.type;

      if (!isStream) {
        chrome.runtime.sendMessage({ action: 'download', url, filename });
        btn.textContent = '✓ Starting...';
        btn.style.boxShadow = '0 0 12px rgba(0,200,122,0.5)';
        btn.style.background = 'linear-gradient(135deg,#0a3a2a,#0d2a1a)';
        btn.style.color = '#00c87a';
        btn.style.border = '1px solid #00c87a';
        setTimeout(() => { btn.textContent = '⬇ Download'; btn.style.cssText = ''; }, 2500);
        return;
      }

      const reqId = `dl_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      liveDownloads[reqId] = { reqId, filename, percent: 0, stage: 'Queued', done: false };
      renderDownloadBanner();
      btn.textContent = '⏳ Queued...';
      btn.disabled = true;
      chrome.runtime.sendMessage({
        action: 'downloadStream', reqId, url, filename, streamType: type || 'HLS'
      });
    });
  });

  list.querySelectorAll('.btn-copy').forEach(btn => {
    btn.addEventListener('click', () => {
      navigator.clipboard.writeText(decodeURIComponent(btn.dataset.url)).then(() => {
        btn.textContent = '✓';
        btn.classList.add('copied');
        setTimeout(() => { btn.textContent = 'Copy'; btn.classList.remove('copied'); }, 2000);
      });
    });
  });
}

// ─── Init ───────────────────────────────────────────────────────────────────
async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  currentTab = tab;
  document.getElementById('page-host').textContent = getHost(tab.url || '');

  renderBlacklistWarning();

  // Restore active downloads from session storage.
  try {
    const stored = await chrome.storage.session.get('activeDownloads');
    liveDownloads = stored.activeDownloads || {};
  } catch { liveDownloads = {}; }

  if (isBlacklisted(tab.url || '')) { render(); return; }

  chrome.runtime.sendMessage({ action: 'getVideos', tabId: tab.id }, res => {
    if (chrome.runtime.lastError) { render(); return; }
    mergeVideos(res?.videos || []);
    render();
  });

  // Best-effort DOM scan trigger (will silently no-op on chrome:// pages etc.)
  chrome.tabs.sendMessage(tab.id, { action: 'scanNow' }).catch(() => {});
}

// ─── Controls ───────────────────────────────────────────────────────────────
document.getElementById('btn-scan').addEventListener('click', () => {
  if (currentTab && isBlacklisted(currentTab.url || '')) return;
  const btn = document.getElementById('btn-scan');
  btn.textContent = '⏳'; btn.disabled = true;
  chrome.tabs.sendMessage(currentTab.id, { action: 'scanNow' }).catch(() => {}).finally(() => {
    chrome.runtime.sendMessage({ action: 'getVideos', tabId: currentTab.id }, res => {
      mergeVideos(res?.videos || []);
      render();
      btn.textContent = '⟳ SCAN'; btn.disabled = false;
    });
  });
});

document.getElementById('btn-clear').addEventListener('click', () => {
  allVideos = {};
  chrome.runtime.sendMessage({ action: 'clearVideos', tabId: currentTab.id });
  render();
});

document.querySelectorAll('.tab').forEach(t => {
  t.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
    t.classList.add('active');
    activeFilter = t.dataset.tab;
    render();
  });
});

// ─── Live updates ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(msg => {
  if (msg.action === 'videoFound' && msg.tabId === currentTab?.id) {
    if (!isBlacklisted(currentTab.url || '')) {
      mergeVideos([msg.video]);
      render();
    }
  }
  if (msg.action === 'streamProgress') {
    const { reqId, percent, stage, error, done, cancelled } = msg;
    if (liveDownloads[reqId]) {
      liveDownloads[reqId] = {
        ...liveDownloads[reqId],
        percent: percent || 0, stage, error,
        done: !!done, cancelled: !!cancelled
      };
      renderDownloadBanner();
      if (done || error || cancelled) {
        document.querySelectorAll('.btn-dl[disabled]').forEach(btn => {
          btn.disabled = false;
          btn.textContent = error ? '✗ Failed — retry?' : cancelled ? '⬇ Stitch & Download' : '✓ Done!';
          if (!error && !cancelled) {
            btn.style.background = 'linear-gradient(135deg,#0a3a2a,#0d2a1a)';
            btn.style.color = '#00c87a';
            btn.style.border = '1px solid #00c87a';
            setTimeout(() => { btn.textContent = '⬇ Stitch & Download'; btn.style.cssText = ''; }, 4000);
          }
        });
      }
    }
  }
});

init();
