// ─────────────────────────────────────────────────────────────────────────────
//  怠竜 VidSnatcher · inject.js · v1.1.0
//  Runs in MAIN world (same JS realm as page scripts).
//  Hooks XHR / fetch / video.src BEFORE any page script runs.
// ─────────────────────────────────────────────────────────────────────────────
(function () {
  'use strict';

  // Avoid double-install if reinjected.
  if (window.__vidsnatcherInstalled) return;
  window.__vidsnatcherInstalled = true;

  // ─── Blacklist — don't hook paid streaming platforms ─────────────────────
  const BL = [
    'netflix.com','primevideo.com','amazon.com','disneyplus.com','hulu.com',
    'max.com','hbomax.com','peacocktv.com','paramountplus.com',
    'appletv.apple.com','crunchyroll.com','funimation.com','mubi.com',
    'curiositystream.com','discoveryplus.com','espnplus.com','starz.com',
    'showtime.com','mgmplus.com','hotstar.com','jiocinema.com','sonyliv.com',
    'zee5.com','tv.apple.com','nowtv.com','britbox.com','acorn.tv','shudder.com'
  ];
  try {
    const h = location.hostname.replace(/^www\./, '');
    if (BL.some(d => h === d || h.endsWith('.' + d))) return;
  } catch { return; }

  const VIDEO_RE = /\.(mp4|webm|mkv|m3u8|m3u|mpd|ts|m4s|m4v|mov|flv|avi|ogv)(\?|#|$)/i;

  const MIME_RE = [
    /^video\//i,
    /application\/x-mpegurl/i,
    /application\/vnd\.apple\.mpegurl/i,
    /application\/dash\+xml/i
  ];

  function isVideoUrl(url) {
    if (!url || typeof url !== 'string') return false;
    if (url.startsWith('blob:') || url.startsWith('mediasource:')) return false;
    try {
      const clean = url.split('?')[0].split('#')[0];
      return VIDEO_RE.test(clean);
    } catch { return false; }
  }

  function isVideoMime(mime) {
    return !!mime && MIME_RE.some(p => p.test(mime));
  }

  function send(url, source, extra = {}) {
    try {
      window.postMessage({
        __vidsnatcher: true,
        url: String(url),
        source,
        timestamp: Date.now(),
        ...extra
      }, '*');
    } catch { /* ignore */ }
  }

  // ─── HOOK 1: XMLHttpRequest ──────────────────────────────────────────────
  const OrigXHR = window.XMLHttpRequest;
  const xhrOpen = OrigXHR.prototype.open;

  OrigXHR.prototype.open = function (method, url) {
    try {
      this._vs_url = url ? String(url) : '';
      if (isVideoUrl(this._vs_url)) send(this._vs_url, 'xhr');
      this.addEventListener('readystatechange', function () {
        if (this.readyState === 2) {
          try {
            const ct = this.getResponseHeader('content-type') || '';
            if (isVideoMime(ct) && this._vs_url) {
              send(this._vs_url, 'xhr-mime', { contentType: ct });
            }
          } catch { /* cross-origin */ }
        }
      });
    } catch { /* swallow — never break the page */ }
    return xhrOpen.apply(this, arguments);
  };

  // ─── HOOK 2: fetch() ─────────────────────────────────────────────────────
  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    let url = '';
    try {
      url = (input instanceof Request ? input.url : String(input)) || '';
      if (isVideoUrl(url)) send(url, 'fetch');
    } catch { /* swallow */ }
    const result = origFetch.apply(this, arguments);
    try {
      result.then(response => {
        try {
          const ct = response.headers.get('content-type') || '';
          if (isVideoMime(ct)) send(response.url || url, 'fetch-mime', { contentType: ct });
        } catch { /* ignore */ }
      }).catch(() => {});
    } catch { /* ignore */ }
    return result;
  };

  // ─── HOOK 3: HTMLMediaElement.src setter ─────────────────────────────────
  try {
    const desc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'src');
    if (desc && desc.set) {
      Object.defineProperty(HTMLMediaElement.prototype, 'src', {
        set(val) {
          try {
            const s = String(val || '');
            if (s && !s.startsWith('blob:') && !s.startsWith('mediasource:')) {
              send(s, 'video-src');
            } else if (s.startsWith('blob:')) {
              send(s, 'blob-src');
            }
          } catch { /* ignore */ }
          desc.set.call(this, val);
        },
        get() { return desc.get.call(this); },
        configurable: true
      });
    }
  } catch { /* ignore */ }

  // ─── HOOK 4: setAttribute on <video>/<source> only ───────────────────────
  // Narrow check so we don't add overhead to every setAttribute on the page.
  try {
    const origSetAttr = Element.prototype.setAttribute;
    Element.prototype.setAttribute = function (name, value) {
      try {
        if (
          name === 'src' &&
          (this instanceof HTMLVideoElement || this instanceof HTMLSourceElement || this instanceof HTMLAudioElement)
        ) {
          const s = String(value || '');
          if (s && !s.startsWith('blob:') && !s.startsWith('mediasource:')) {
            send(s, 'setattr-src');
          }
        }
      } catch { /* ignore */ }
      return origSetAttr.apply(this, arguments);
    };
  } catch { /* ignore */ }

  // ─── HOOK 5: MediaSource (info-only — these can't be downloaded) ─────────
  // We REPORT that the page is using MediaSource so the user knows, but we
  // tag the entry with isBlob:true and no real URL — the content script will
  // suppress fake mediasource:// URLs from the downloadable list.
  try {
    if (window.MediaSource) {
      const origAdd = window.MediaSource.prototype.addSourceBuffer;
      let reported = false;
      window.MediaSource.prototype.addSourceBuffer = function (mimeType) {
        if (!reported) {
          reported = true;
          send('mediasource://' + mimeType, 'mediasource', {
            mimeType,
            note: 'Page uses MediaSource — the real segments above (m3u8 / mpd / m4s) are what to grab.'
          });
        }
        return origAdd.apply(this, arguments);
      };
    }
  } catch { /* ignore */ }

  // NOTE: removed window.eval and document.write hooks from previous version.
  // Overriding window.eval breaks scope semantics on many sites and tanks
  // pages that legitimately use eval (Webpack, some SPA bootstraps). The
  // XHR/fetch hooks above already catch the vast majority of video URLs.
})();
