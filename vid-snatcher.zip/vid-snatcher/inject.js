// ─────────────────────────────────────────────────────────────────────────────
//  怠竜 VidSnatcher · inject.js · v1.1.0
//  Runs in MAIN world (same JS realm as page scripts).
//  Hooks XHR / fetch / video.src BEFORE any page script runs.
// ─────────────────────────────────────────────────────────────────────────────
(function () {
  'use strict';

  // Avoid double-install if reinjected.
  if (window.__vidsnatcherInstalled) return;
  window.__vidsnatcherInstalled = true;

  // ─── Blacklist — don't hook paid streaming platforms ─────────────────────
  const BL = [
    'netflix.com','primevideo.com','amazon.com','disneyplus.com','hulu.com',
    'max.com','hbomax.com','peacocktv.com','paramountplus.com',
    'appletv.apple.com','crunchyroll.com','funimation.com','mubi.com',
    'curiositystream.com','discoveryplus.com','espnplus.com','starz.com',
    'showtime.com','mgmplus.com','hotstar.com','jiocinema.com','sonyliv.com',
    'zee5.com','tv.apple.com','nowtv.com','britbox.com','acorn.tv','shudder.com'
  ];
  try {
    const h = location.hostname.replace(/^www\./, '');
    if (BL.some(d => h === d || h.endsWith('.' + d))) return;
  } catch { return; }

  const VIDEO_RE = /\.(mp4|webm|mkv|m3u8|m3u|mpd|ts|m4s|m4v|mov|flv|avi|ogv)(\?|#|$)/i;

  const MIME_RE = [
    /^video\//i,
    /application\/x-mpegurl/i,
    /application\/vnd\.apple\.mpegurl/i,
    /application\/dash\+xml/i
  ];

  function isVideoUrl(url) {
    if (!url || typeof url !== 'string') return false;
    if (url.startsWith('blob:') || url.startsWith('mediasource:')) return false;
    try {
      const clean = url.split('?')[0].split('#')[0];
      return VIDEO_RE.test(clean);
    } catch { return false; }
  }

  function isVideoMime(mime) {
    return !!mime && MIME_RE.some(p => p.test(mime));
  }

  function send(url, source, extra = {}) {
    try {
      window.postMessage({
        __vidsnatcher: true,
        url: String(url),
        source,
        timestamp: Date.now(),
        ...extra
      }, '*');
    } catch { /* ignore */ }
  }

  // ─── HOOK 1: XMLHttpRequest ──────────────────────────────────────────────
  const OrigXHR = window.XMLHttpRequest;
  const xhrOpen = OrigXHR.prototype.open;

  OrigXHR.prototype.open = function (method, url) {
    try {
      this._vs_url = url ? String(url) : '';
      if (isVideoUrl(this._vs_url)) send(this._vs_url, 'xhr');
      this.addEventListener('readystatechange', function () {
        if (this.readyState === 2) {
          try {
            const ct = this.getResponseHeader('content-type') || '';
            if (isVideoMime(ct) && this._vs_url) {
              send(this._vs_url, 'xhr-mime', { contentType: ct });
            }
          } catch { /* cross-origin */ }
        }
      });
    } catch { /* swallow — never break the page */ }
    return xhrOpen.apply(this, arguments);
  };

  // ─── HOOK 2: fetch() ─────────────────────────────────────────────────────
  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    let url = '';
    try {
      url = (input instanceof Request ? input.url : String(input)) || '';
      if (isVideoUrl(url)) send(url, 'fetch');
    } catch { /* swallow */ }
    const result = origFetch.apply(this, arguments);
    try {
      result.then(response => {
        try {
          const ct = response.headers.get('content-type') || '';
          if (isVideoMime(ct)) send(response.url || url, 'fetch-mime', { contentType: ct });
        } catch { /* ignore */ }
      }).catch(() => {});
    } catch { /* ignore */ }
    return result;
  };

  // ─── HOOK 3: HTMLMediaElement.src setter ─────────────────────────────────
  try {
    const desc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'src');
    if (desc && desc.set) {
      Object.defineProperty(HTMLMediaElement.prototype, 'src', {
        set(val) {
          try {
            const s = String(val || '');
            if (s && !s.startsWith('blob:') && !s.startsWith('mediasource:')) {
              send(s, 'video-src');
            } else if (s.startsWith('blob:')) {
              send(s, 'blob-src');
            }
          } catch { /* ignore */ }
          desc.set.call(this, val);
        },
        get() { return desc.get.call(this); },
        configurable: true
      });
    }
  } catch { /* ignore */ }

  // ─── HOOK 4: setAttribute on <video>/<source> only ───────────────────────
  // Narrow check so we don't add overhead to every setAttribute on the page.
  try {
    const origSetAttr = Element.prototype.setAttribute;
    Element.prototype.setAttribute = function (name, value) {
      try {
        if (
          name === 'src' &&
          (this instanceof HTMLVideoElement || this instanceof HTMLSourceElement || this instanceof HTMLAudioElement)
        ) {
          const s = String(value || '');
          if (s && !s.startsWith('blob:') && !s.startsWith('mediasource:')) {
            send(s, 'setattr-src');
          }
        }
      } catch { /* ignore */ }
      return origSetAttr.apply(this, arguments);
    };
  } catch { /* ignore */ }

  // ─── HOOK 5: MediaSource buffer capture (v1.2) ───────────────────────────
  // Hook SourceBuffer.appendBuffer to collect every chunk the page feeds into
  // MediaSource. For sites that bypass our XHR/fetch hooks (rare but possible),
  // this is the last-resort way to capture the raw video bytes.
  //
  // Buffered chunks are kept on window.__vidsnatcherMSE so the content script
  // can hand them off to the popup → background → offscreen when the user
  // clicks "Download MSE Buffer".
  try {
    if (window.MediaSource && window.MediaSource.prototype) {
      const origAdd = window.MediaSource.prototype.addSourceBuffer;
      window.__vidsnatcherMSE = window.__vidsnatcherMSE || { buffers: [], totalBytes: 0, mimeType: null };
      let reported = false;

      window.MediaSource.prototype.addSourceBuffer = function (mimeType) {
        const sb = origAdd.apply(this, arguments);
        // Remember the mime so the popup can offer correct extension/MIME on download.
        if (!window.__vidsnatcherMSE.mimeType) window.__vidsnatcherMSE.mimeType = mimeType;

        // Hook appendBuffer on THIS SourceBuffer to capture chunks.
        try {
          const origAppend = sb.appendBuffer;
          sb.appendBuffer = function (chunk) {
            try {
              if (chunk && (chunk.byteLength || chunk.length)) {
                // Copy the bytes (the page may reuse the buffer).
                const view = chunk instanceof ArrayBuffer ? new Uint8Array(chunk) : new Uint8Array(chunk.buffer, chunk.byteOffset, chunk.byteLength);
                const copy = new Uint8Array(view.byteLength);
                copy.set(view);
                window.__vidsnatcherMSE.buffers.push(copy);
                window.__vidsnatcherMSE.totalBytes += copy.byteLength;
                // Cap at 2 GB so we don't OOM. Older chunks drop first.
                while (window.__vidsnatcherMSE.totalBytes > 2 * 1024 * 1024 * 1024 && window.__vidsnatcherMSE.buffers.length > 1) {
                  const removed = window.__vidsnatcherMSE.buffers.shift();
                  window.__vidsnatcherMSE.totalBytes -= removed.byteLength;
                }
                // Report a "downloadable MSE capture" entry on first chunk.
                if (!reported) {
                  reported = true;
                  send('mse-capture://' + (mimeType || 'unknown'), 'mse-capture', {
                    mimeType,
                    note: 'MediaSource buffer being captured in real-time. Click DOWNLOAD MSE CAPTURE to save the accumulated video data. Best results after the video has fully played.'
                  });
                }
              }
            } catch (e) { /* swallow — never break the page's media pipeline */ }
            return origAppend.apply(this, arguments);
          };
        } catch { /* ignore — appendBuffer not assignable */ }

        return sb;
      };

      // Expose a getter so the content script can grab the accumulated bytes.
      window.__vidsnatcherGetMSE = function () {
        const buffers = window.__vidsnatcherMSE.buffers;
        const total = window.__vidsnatcherMSE.totalBytes;
        return { buffers, totalBytes: total, mimeType: window.__vidsnatcherMSE.mimeType };
      };

      // Bridge: content script (isolated world) postMessages a request; we reply.
      window.addEventListener('message', (ev) => {
        if (ev.source !== window) return;
        const req = ev.data && ev.data.__vidsnatcherMSERequest;
        if (!req) return;
        try {
          const data = window.__vidsnatcherGetMSE();
          // postMessage will structured-clone the typed arrays; copies are safe.
          window.postMessage({
            __vidsnatcherMSEReply: req,
            buffers: data.buffers,
            totalBytes: data.totalBytes,
            mimeType: data.mimeType
          }, '*');
        } catch (e) {
          window.postMessage({ __vidsnatcherMSEReply: req, error: e.message }, '*');
        }
      });
    }
  } catch { /* ignore */ }

  // NOTE: removed window.eval and document.write hooks from previous version.
  // Overriding window.eval breaks scope semantics on many sites and tanks
  // pages that legitimately use eval (Webpack, some SPA bootstraps). The
  // XHR/fetch hooks above already catch the vast majority of video URLs.
})();
