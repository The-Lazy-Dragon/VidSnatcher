// ─────────────────────────────────────────────────────────────────────────────
//  怠竜 VidSnatcher · offscreen.js · v1.1.0
//  Persistent download engine — runs in offscreen document, survives popup close.
//  Handles: HLS / DASH parsing, fMP4 init segments, AES-128, concurrent fetch.
// ─────────────────────────────────────────────────────────────────────────────

const activeControllers = {}; // reqId → AbortController
const PARALLEL = 6;           // concurrent segment downloads per stream
const RETRIES  = 3;           // per-segment retry count

// ─── Utils ──────────────────────────────────────────────────────────────────
function resolveUrl(base, relative) {
  try { return new URL(relative, base).toString(); } catch { return relative; }
}

function prog(reqId, percent, stage, extra = {}) {
  chrome.runtime.sendMessage({
    action: 'progressUpdate', reqId, percent, stage, ...extra
  }).catch(()=>{});
}

async function fetchBuf(url, signal) {
  let lastErr;
  for (let attempt = 0; attempt < RETRIES; attempt++) {
    if (signal?.aborted) throw new DOMException('aborted', 'AbortError');
    try {
      const res = await fetch(url, { credentials: 'omit', signal });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.arrayBuffer();
    } catch (e) {
      if (e.name === 'AbortError') throw e;
      lastErr = e;
      // Exponential backoff: 300ms, 600ms, 1200ms
      await new Promise(r => setTimeout(r, 300 * Math.pow(2, attempt)));
    }
  }
  throw lastErr;
}

async function fetchText(url, signal) {
  const res = await fetch(url, { credentials: 'omit', signal });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.text();
}

// ─── AES-128 ────────────────────────────────────────────────────────────────
const keyCache = {};

async function getAesKey(uri, signal) {
  if (keyCache[uri]) return keyCache[uri];
  const buf = await fetchBuf(uri, signal);
  const key = await crypto.subtle.importKey('raw', buf, 'AES-CBC', false, ['decrypt']);
  keyCache[uri] = key;
  return key;
}

function buildIV(ivHex, segIndex) {
  const iv = new Uint8Array(16);
  if (ivHex) {
    const hex = ivHex.replace(/^0x/i, '').padStart(32, '0');
    for (let i = 0; i < 16; i++) iv[i] = parseInt(hex.substr(i * 2, 2), 16);
  } else {
    new DataView(iv.buffer).setUint32(12, segIndex, false);
  }
  return iv;
}

// ─── HLS Parser ─────────────────────────────────────────────────────────────
async function parseHLS(m3u8Url, signal) {
  const text = await fetchText(m3u8Url, signal);

  // Master playlist? Pick best stream.
  if (text.includes('#EXT-X-STREAM-INF')) {
    const streams = [];
    const lines = text.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.startsWith('#EXT-X-STREAM-INF')) {
        const bw  = parseInt(line.match(/BANDWIDTH=(\d+)/i)?.[1] || '0');
        const res = line.match(/RESOLUTION=(\d+x\d+)/i)?.[1] || null;
        const next = lines[i + 1]?.trim();
        if (next && !next.startsWith('#')) {
          streams.push({ url: resolveUrl(m3u8Url, next), bandwidth: bw, resolution: res });
        }
      }
    }
    if (!streams.length) throw new Error('No streams in master playlist');
    streams.sort((a, b) => b.bandwidth - a.bandwidth);
    return { masterStreams: streams, bestUrl: streams[0].url };
  }

  // Media playlist.
  const segments = [];
  const lines = text.split('\n');
  let encMethod = 'NONE', encKeyUri = null, encIV = null, segIndex = 0;
  let initSegment = null;
  let segmentExt = null; // detected from first segment URL

  for (const rawLine of lines) {
    const line = rawLine.trim();

    if (line.startsWith('#EXT-X-MAP')) {
      // fMP4 init segment: '#EXT-X-MAP:URI="init.mp4"[,BYTERANGE="..."]'
      const uri = line.match(/URI="([^"]+)"/)?.[1];
      if (uri) initSegment = resolveUrl(m3u8Url, uri);
      continue;
    }

    if (line.startsWith('#EXT-X-KEY')) {
      const method = line.match(/METHOD=([^,\s]+)/)?.[1] || 'NONE';
      const uri    = line.match(/URI="([^"]+)"/)?.[1] || null;
      const iv     = line.match(/IV=(0x[0-9a-f]+)/i)?.[1] || null;
      encMethod = method;
      encKeyUri = uri ? resolveUrl(m3u8Url, uri) : null;
      encIV = iv;
      if (method === 'SAMPLE-AES' || method === 'SAMPLE-AES-CTR') {
        return { error: `${method} (DRM-style) detected — can't decrypt.` };
      }
      continue;
    }

    if (!line.startsWith('#') && line.length > 0) {
      const segUrl = resolveUrl(m3u8Url, line);
      if (!segmentExt) {
        const m = segUrl.match(/\.([a-z0-9]+)(?:\?|#|$)/i);
        if (m) segmentExt = m[1].toLowerCase();
      }
      segments.push({
        url: segUrl,
        encrypted: encMethod === 'AES-128',
        keyUri: encKeyUri,
        iv: encIV,
        index: segIndex++
      });
    }
  }

  // Pick container: if init segment is present OR segments are .m4s/.mp4, it's fMP4.
  const container = initSegment || segmentExt === 'm4s' || segmentExt === 'mp4'
    ? 'fmp4'
    : 'ts';

  return {
    segments,
    initSegment,
    totalSegments: segments.length,
    encrypted: encMethod === 'AES-128',
    container
  };
}

// ─── DASH Parser ────────────────────────────────────────────────────────────
//  Parses a single Representation per AdaptationSet (video only by default —
//  audio mux would need a remuxer that doesn't exist in-browser).
async function parseDASH(mpdUrl, signal) {
  const text = await fetchText(mpdUrl, signal);
  const doc = new DOMParser().parseFromString(text, 'application/xml');
  if (doc.querySelector('parsererror')) throw new Error('MPD parse error');

  // Resolve BaseURL chain (MPD → Period → AdaptationSet → Representation).
  function baseChain(node) {
    const urls = [];
    let cur = node;
    while (cur) {
      const b = cur.querySelector(':scope > BaseURL')?.textContent?.trim();
      if (b) urls.unshift(b);
      cur = cur.parentElement;
    }
    let resolved = mpdUrl;
    for (const u of urls) resolved = resolveUrl(resolved, u);
    return resolved;
  }

  // Total duration in seconds from mediaPresentationDuration="PT1H2M30.5S"
  const durStr = doc.documentElement.getAttribute('mediaPresentationDuration') || 'PT0S';
  const dh = parseFloat(durStr.match(/(\d+(?:\.\d+)?)H/)?.[1] || 0);
  const dm = parseFloat(durStr.match(/(\d+(?:\.\d+)?)M/)?.[1] || 0);
  const ds = parseFloat(durStr.match(/(\d+(?:\.\d+)?)S/)?.[1] || 0);
  const totalDuration = dh * 3600 + dm * 60 + ds;

  // Find best video AdaptationSet.
  const adapts = Array.from(doc.querySelectorAll('AdaptationSet'));
  const videoAdapts = adapts.filter(a => {
    const ct = a.getAttribute('contentType') || a.getAttribute('mimeType') || '';
    return /video/i.test(ct) ||
      Array.from(a.querySelectorAll('Representation')).some(r =>
        /video/i.test(r.getAttribute('mimeType') || ''));
  });
  const chosen = (videoAdapts[0] || adapts[0]);
  if (!chosen) throw new Error('No AdaptationSet in MPD');

  // Pick highest-bandwidth Representation.
  const reps = Array.from(chosen.querySelectorAll('Representation'));
  reps.sort((a, b) => (+b.getAttribute('bandwidth') || 0) - (+a.getAttribute('bandwidth') || 0));
  const rep = reps[0];
  if (!rep) throw new Error('No Representation in AdaptationSet');

  const repId = rep.getAttribute('id') || '1';
  const bandwidth = +rep.getAttribute('bandwidth') || 0;
  const resolution = rep.getAttribute('width') && rep.getAttribute('height')
    ? `${rep.getAttribute('width')}x${rep.getAttribute('height')}`
    : null;

  const repBase = baseChain(rep);

  // Strategy 1: SegmentTemplate (most common modern DASH).
  const tmpl = rep.querySelector(':scope > SegmentTemplate') ||
               chosen.querySelector(':scope > SegmentTemplate');

  function fillTemplate(t, vars) {
    return t.replace(/\$(RepresentationID|Number|Time|Bandwidth)(%0(\d+)d)?\$/g, (_, key, _w, pad) => {
      let v = vars[key];
      if (v === undefined) return '';
      if (pad) v = String(v).padStart(parseInt(pad), '0');
      return String(v);
    });
  }

  if (tmpl) {
    const segments = [];
    const initTpl = tmpl.getAttribute('initialization');
    const mediaTpl = tmpl.getAttribute('media');
    const timescale = +tmpl.getAttribute('timescale') || 1;
    const duration  = +tmpl.getAttribute('duration')  || 0;
    const startNumber = +tmpl.getAttribute('startNumber') || 1;

    const initSegment = initTpl
      ? resolveUrl(repBase, fillTemplate(initTpl, { RepresentationID: repId, Bandwidth: bandwidth }))
      : null;

    // SegmentTimeline overrides duration math.
    const timeline = tmpl.querySelector('SegmentTimeline');
    if (timeline) {
      let time = 0, segIdx = 0, n = startNumber;
      for (const S of timeline.querySelectorAll('S')) {
        if (S.hasAttribute('t')) time = +S.getAttribute('t');
        const d = +S.getAttribute('d');
        const r = +S.getAttribute('r') || 0;
        for (let i = 0; i <= r; i++) {
          const url = resolveUrl(repBase, fillTemplate(mediaTpl, {
            RepresentationID: repId, Number: n, Time: time, Bandwidth: bandwidth
          }));
          segments.push({ url, index: segIdx++, encrypted: false });
          time += d;
          n++;
        }
      }
      return { segments, initSegment, totalSegments: segments.length, container: 'fmp4', resolution, bandwidth };
    }

    // Number-based template with duration.
    if (mediaTpl && duration > 0 && totalDuration > 0) {
      const segDurSec = duration / timescale;
      const count = Math.ceil(totalDuration / segDurSec);
      for (let i = 0; i < count; i++) {
        const n = startNumber + i;
        const url = resolveUrl(repBase, fillTemplate(mediaTpl, {
          RepresentationID: repId, Number: n, Bandwidth: bandwidth
        }));
        segments.push({ url, index: i, encrypted: false });
      }
      return { segments, initSegment, totalSegments: segments.length, container: 'fmp4', resolution, bandwidth };
    }
  }

  // Strategy 2: SegmentList.
  const segList = rep.querySelector(':scope > SegmentList');
  if (segList) {
    const segments = [];
    const initUrl = segList.querySelector('Initialization')?.getAttribute('sourceURL');
    const initSegment = initUrl ? resolveUrl(repBase, initUrl) : null;
    Array.from(segList.querySelectorAll('SegmentURL')).forEach((s, i) => {
      const media = s.getAttribute('media');
      if (media) {
        segments.push({ url: resolveUrl(repBase, media), index: i, encrypted: false });
      }
    });
    return { segments, initSegment, totalSegments: segments.length, container: 'fmp4', resolution, bandwidth };
  }

  // Strategy 3: SegmentBase (single-file) — just download the whole rep URL.
  const base = rep.querySelector(':scope > BaseURL')?.textContent?.trim();
  if (base) {
    const url = resolveUrl(repBase, base);
    return {
      segments: [{ url, index: 0, encrypted: false }],
      initSegment: null,
      totalSegments: 1,
      container: 'fmp4',
      resolution, bandwidth
    };
  }

  throw new Error('Could not parse DASH manifest — unsupported structure.');
}

// ─── Parallel segment fetch ─────────────────────────────────────────────────
async function fetchAllSegments({ segments, signal, onSegment, onFail }) {
  const buffers = new Array(segments.length);
  let failedCount = 0;
  const maxFails = Math.max(3, Math.ceil(segments.length * 0.05));
  let i = 0;

  async function worker() {
    while (i < segments.length) {
      if (signal.aborted) return;
      const myIdx = i++;
      const seg = segments[myIdx];
      try {
        let buf = await fetchBuf(seg.url, signal);
        if (seg.encrypted && seg.keyUri) {
          const key = await getAesKey(seg.keyUri, signal);
          const iv = buildIV(seg.iv, seg.index);
          buf = await crypto.subtle.decrypt({ name: 'AES-CBC', iv }, key, buf);
        }
        buffers[myIdx] = buf;
        onSegment?.(myIdx, segments.length);
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        failedCount++;
        onFail?.(myIdx, e, failedCount);
        if (failedCount > maxFails) {
          throw new Error(`Too many segment failures (${failedCount}). Aborted.`);
        }
        // Mark as empty so concatenation skips it.
        buffers[myIdx] = new ArrayBuffer(0);
      }
    }
  }

  const workers = Array.from({ length: Math.min(PARALLEL, segments.length) }, worker);
  await Promise.all(workers);
  return { buffers, failedCount };
}

// ─── Main engine ────────────────────────────────────────────────────────────
async function downloadStream({ reqId, url, filename, streamType }) {
  const controller = new AbortController();
  activeControllers[reqId] = controller;
  const { signal } = controller;
  const send = (pct, stage, extra = {}) => prog(reqId, pct, stage, extra);

  try {
    send(0, 'Parsing manifest...');

    let parsed = streamType === 'HLS'
      ? await parseHLS(url, signal)
      : await parseDASH(url, signal);

    if (parsed.error) { send(0, '', { error: parsed.error, done: true }); return; }

    // Master playlist → resolve to best media playlist.
    if (parsed.masterStreams) {
      const list = parsed.masterStreams
        .map(s => `${s.resolution || '?'} (${Math.round(s.bandwidth / 1000)}kbps)`)
        .join(' · ');
      send(2, `${parsed.masterStreams.length} streams → best: ${parsed.masterStreams[0].resolution || 'highest bitrate'} | ${list}`);
      parsed = await parseHLS(parsed.bestUrl, signal);
      if (parsed.error) { send(0, '', { error: parsed.error, done: true }); return; }
    }

    const { segments, initSegment, container, encrypted } = parsed;
    if (!segments?.length) {
      send(0, '', { error: 'No segments found in manifest.', done: true });
      return;
    }

    const encNote = encrypted ? ' 🔓 AES-128' : '';
    const initNote = initSegment ? ' + init' : '';
    send(5, `Downloading ${segments.length} segments${initNote}${encNote} (×${PARALLEL} parallel)...`);

    // Fetch init segment first (if present).
    let initBuf = null;
    if (initSegment) {
      try {
        initBuf = await fetchBuf(initSegment, signal);
      } catch (e) {
        if (e.name === 'AbortError') {
          send(0, '', { error: 'Cancelled by user.', done: true, cancelled: true });
          return;
        }
        send(0, '', { error: `Init segment failed: ${e.message}`, done: true });
        return;
      }
    }

    // Parallel segment fetch with live progress.
    let lastReported = -1;
    let completed = 0;
    const { buffers, failedCount } = await fetchAllSegments({
      segments,
      signal,
      onSegment: () => {
        completed++;
        const pct = 5 + Math.floor(completed / segments.length * 82);
        if (pct !== lastReported || completed === segments.length) {
          lastReported = pct;
          send(pct, `Segment ${completed}/${segments.length}${encrypted ? ' 🔓' : ''}`);
        }
      }
    });

    if (signal.aborted) {
      send(0, '', { error: 'Cancelled by user.', done: true, cancelled: true });
      return;
    }

    send(90, 'Stitching...');

    // Combine: init segment first, then all media segments in order.
    const parts = initBuf ? [initBuf, ...buffers] : buffers;
    const totalBytes = parts.reduce((a, b) => a + b.byteLength, 0);
    const combined = new Uint8Array(totalBytes);
    let offset = 0;
    for (const buf of parts) {
      combined.set(new Uint8Array(buf), offset);
      offset += buf.byteLength;
    }

    send(96, 'Preparing download...');

    // Pick extension based on detected container.
    const ext = container === 'fmp4' ? '.mp4' : '.ts';
    const baseName = filename.replace(/\.[^.]+$/, '').replace(/[^\w\-. ]/g, '_') || 'video';
    const outName = baseName + ext;
    const mimeType = container === 'fmp4' ? 'video/mp4' : 'video/mp2t';

    const blob = new Blob([combined], { type: mimeType });
    const blobUrl = URL.createObjectURL(blob);

    chrome.runtime.sendMessage({
      action: 'triggerDownload', blobUrl, filename: outName, reqId
    }).catch(()=>{});

    // Revoke after 2 mins (download has long since started).
    setTimeout(() => URL.revokeObjectURL(blobUrl), 120000);

    const sizeMB = (totalBytes / 1024 / 1024).toFixed(1);
    const fmt = container === 'fmp4' ? '.mp4 (fMP4)' : '.ts (MPEG-TS)';
    send(100, `Done! ${outName} · ${sizeMB} MB · ${fmt}${failedCount ? ` (${failedCount} segs skipped)` : ''}`, { done: true });

  } catch (e) {
    if (e.name === 'AbortError') {
      prog(reqId, 0, '', { error: 'Cancelled by user.', done: true, cancelled: true });
    } else {
      prog(reqId, 0, '', { error: e.message || String(e), done: true });
    }
  } finally {
    delete activeControllers[reqId];
  }
}

// ─── Message handler ────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === 'offscreen_startDownload') {
    downloadStream(msg).catch(e => {
      chrome.runtime.sendMessage({
        action: 'progressUpdate', reqId: msg.reqId,
        percent: 0, stage: '', error: e.message || String(e), done: true
      }).catch(()=>{});
    });
  }
  if (msg.action === 'offscreen_cancel') {
    const ctrl = activeControllers[msg.reqId];
    if (ctrl) { ctrl.abort(); delete activeControllers[msg.reqId]; }
  }
});
