// ─────────────────────────────────────────────────────────────────────────────
//  怠竜 VidSnatcher · offscreen.js · v1.1.0
//  Persistent download engine — runs in offscreen document, survives popup close.
//  Handles: HLS / DASH parsing, fMP4 init segments, AES-128, concurrent fetch.
// ─────────────────────────────────────────────────────────────────────────────

const activeControllers = {}; // reqId → AbortController
const PARALLEL = 6;           // concurrent segment downloads per stream
const RETRIES  = 3;           // per-segment retry count

// ─── Utils ──────────────────────────────────────────────────────────────────
function resolveUrl(base, relative) {
  try { return new URL(relative, base).toString(); } catch { return relative; }
}

function prog(reqId, percent, stage, extra = {}) {
  chrome.runtime.sendMessage({
    action: 'progressUpdate', reqId, percent, stage, ...extra
  }).catch(()=>{});
}

async function fetchBuf(url, signal) {
  let lastErr;
  for (let attempt = 0; attempt < RETRIES; attempt++) {
    if (signal?.aborted) throw new DOMException('aborted', 'AbortError');
    try {
      const res = await fetch(url, { credentials: 'omit', signal });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.arrayBuffer();
    } catch (e) {
      if (e.name === 'AbortError') throw e;
      lastErr = e;
      // Exponential backoff: 300ms, 600ms, 1200ms
      await new Promise(r => setTimeout(r, 300 * Math.pow(2, attempt)));
    }
  }
  throw lastErr;
}

async function fetchText(url, signal) {
  const res = await fetch(url, { credentials: 'omit', signal });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.text();
}

// ─── AES-128 ────────────────────────────────────────────────────────────────
const keyCache = {};

async function getAesKey(uri, signal) {
  if (keyCache[uri]) return keyCache[uri];
  const buf = await fetchBuf(uri, signal);
  const key = await crypto.subtle.importKey('raw', buf, 'AES-CBC', false, ['decrypt']);
  keyCache[uri] = key;
  return key;
}

function buildIV(ivHex, segIndex) {
  const iv = new Uint8Array(16);
  if (ivHex) {
    const hex = ivHex.replace(/^0x/i, '').padStart(32, '0');
    for (let i = 0; i < 16; i++) iv[i] = parseInt(hex.substr(i * 2, 2), 16);
  } else {
    new DataView(iv.buffer).setUint32(12, segIndex, false);
  }
  return iv;
}

// ─── HLS Parser ─────────────────────────────────────────────────────────────
async function parseHLS(m3u8Url, signal) {
  const text = await fetchText(m3u8Url, signal);

  // Master playlist? Pick best stream + parse audio renditions.
  if (text.includes('#EXT-X-STREAM-INF') || text.includes('#EXT-X-MEDIA')) {
    const streams = [];
    const audioRenditions = []; // group-id → [{ name, lang, default, url }]
    const lines = text.split('\n');

    // First pass: collect EXT-X-MEDIA audio renditions.
    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (line.startsWith('#EXT-X-MEDIA') && line.includes('TYPE=AUDIO')) {
        const group = line.match(/GROUP-ID="([^"]+)"/i)?.[1];
        const name  = line.match(/NAME="([^"]+)"/i)?.[1] || 'audio';
        const lang  = line.match(/LANGUAGE="([^"]+)"/i)?.[1] || '';
        const uri   = line.match(/URI="([^"]+)"/i)?.[1];
        const def   = /DEFAULT=YES/i.test(line);
        if (group && uri) {
          audioRenditions.push({ group, name, lang, default: def, url: resolveUrl(m3u8Url, uri) });
        }
      }
    }

    // Second pass: collect EXT-X-STREAM-INF video streams.
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.startsWith('#EXT-X-STREAM-INF')) {
        const bw       = parseInt(line.match(/BANDWIDTH=(\d+)/i)?.[1] || '0');
        const res      = line.match(/RESOLUTION=(\d+x\d+)/i)?.[1] || null;
        const codecs   = line.match(/CODECS="([^"]+)"/i)?.[1] || '';
        const audioGrp = line.match(/AUDIO="([^"]+)"/i)?.[1] || null;
        const next = lines[i + 1]?.trim();
        if (next && !next.startsWith('#')) {
          streams.push({
            url: resolveUrl(m3u8Url, next),
            bandwidth: bw, resolution: res, codecs, audioGroup: audioGrp,
            // hasAudio = no separate AUDIO group OR codecs explicitly include an audio codec (mp4a, ac-3, etc.)
            hasMuxedAudio: !audioGrp || /mp4a|ac-3|opus|vorbis|ec-3/i.test(codecs)
          });
        }
      }
    }

    if (!streams.length) throw new Error('Master playlist has no video streams (only audio?)');
    streams.sort((a, b) => b.bandwidth - a.bandwidth);

    // v1.2: prefer muxed streams (no separate audio). Only fall back to
    // video+audio-separate if every stream has a separate audio track.
    const muxedStreams = streams.filter(s => s.hasMuxedAudio);
    const bestMuxed = muxedStreams[0];
    const best = bestMuxed || streams[0];

    // If we had to pick a video-only stream, find its matching audio rendition.
    let separateAudioUrl = null;
    if (!bestMuxed && best.audioGroup) {
      const audio = audioRenditions.find(a => a.group === best.audioGroup && a.default)
                 || audioRenditions.find(a => a.group === best.audioGroup);
      if (audio) separateAudioUrl = audio.url;
    }

    return {
      masterStreams: streams,
      bestUrl: best.url,
      bestIsMuxed: !!bestMuxed,
      separateAudioUrl,
      audioRenditionCount: audioRenditions.length
    };
  }

  // Media playlist.
  const segments = [];
  const lines = text.split('\n');
  let encMethod = 'NONE', encKeyUri = null, encIV = null, segIndex = 0;
  let initSegment = null;
  let segmentExt = null; // detected from first segment URL

  for (const rawLine of lines) {
    const line = rawLine.trim();

    if (line.startsWith('#EXT-X-MAP')) {
      // fMP4 init segment: '#EXT-X-MAP:URI="init.mp4"[,BYTERANGE="..."]'
      const uri = line.match(/URI="([^"]+)"/)?.[1];
      if (uri) initSegment = resolveUrl(m3u8Url, uri);
      continue;
    }

    if (line.startsWith('#EXT-X-KEY')) {
      const method = line.match(/METHOD=([^,\s]+)/)?.[1] || 'NONE';
      const uri    = line.match(/URI="([^"]+)"/)?.[1] || null;
      const iv     = line.match(/IV=(0x[0-9a-f]+)/i)?.[1] || null;
      encMethod = method;
      encKeyUri = uri ? resolveUrl(m3u8Url, uri) : null;
      encIV = iv;
      if (method === 'SAMPLE-AES' || method === 'SAMPLE-AES-CTR') {
        return { error: `${method} (DRM-style) detected — can't decrypt.` };
      }
      continue;
    }

    if (!line.startsWith('#') && line.length > 0) {
      const segUrl = resolveUrl(m3u8Url, line);
      if (!segmentExt) {
        const m = segUrl.match(/\.([a-z0-9]+)(?:\?|#|$)/i);
        if (m) segmentExt = m[1].toLowerCase();
      }
      segments.push({
        url: segUrl,
        encrypted: encMethod === 'AES-128',
        keyUri: encKeyUri,
        iv: encIV,
        index: segIndex++
      });
    }
  }

  // Pick container: if init segment is present OR segments are .m4s/.mp4, it's fMP4.
  const container = initSegment || segmentExt === 'm4s' || segmentExt === 'mp4'
    ? 'fmp4'
    : 'ts';

  return {
    segments,
    initSegment,
    totalSegments: segments.length,
    encrypted: encMethod === 'AES-128',
    container
  };
}

// ─── DASH Parser ────────────────────────────────────────────────────────────
//  Parses a single Representation per AdaptationSet (video only by default —
//  audio mux would need a remuxer that doesn't exist in-browser).
async function parseDASH(mpdUrl, signal) {
  const text = await fetchText(mpdUrl, signal);
  const doc = new DOMParser().parseFromString(text, 'application/xml');
  if (doc.querySelector('parsererror')) throw new Error('MPD parse error');

  // Resolve BaseURL chain (MPD → Period → AdaptationSet → Representation).
  function baseChain(node) {
    const urls = [];
    let cur = node;
    while (cur) {
      const b = cur.querySelector(':scope > BaseURL')?.textContent?.trim();
      if (b) urls.unshift(b);
      cur = cur.parentElement;
    }
    let resolved = mpdUrl;
    for (const u of urls) resolved = resolveUrl(resolved, u);
    return resolved;
  }

  // Total duration in seconds from mediaPresentationDuration="PT1H2M30.5S"
  const durStr = doc.documentElement.getAttribute('mediaPresentationDuration') || 'PT0S';
  const dh = parseFloat(durStr.match(/(\d+(?:\.\d+)?)H/)?.[1] || 0);
  const dm = parseFloat(durStr.match(/(\d+(?:\.\d+)?)M/)?.[1] || 0);
  const ds = parseFloat(durStr.match(/(\d+(?:\.\d+)?)S/)?.[1] || 0);
  const totalDuration = dh * 3600 + dm * 60 + ds;

  // Find best video AdaptationSet.
  const adapts = Array.from(doc.querySelectorAll('AdaptationSet'));
  const videoAdapts = adapts.filter(a => {
    const ct = a.getAttribute('contentType') || a.getAttribute('mimeType') || '';
    return /video/i.test(ct) ||
      Array.from(a.querySelectorAll('Representation')).some(r =>
        /video/i.test(r.getAttribute('mimeType') || ''));
  });
  const chosen = (videoAdapts[0] || adapts[0]);
  if (!chosen) throw new Error('No AdaptationSet in MPD');

  // Pick highest-bandwidth Representation.
  const reps = Array.from(chosen.querySelectorAll('Representation'));
  reps.sort((a, b) => (+b.getAttribute('bandwidth') || 0) - (+a.getAttribute('bandwidth') || 0));
  const rep = reps[0];
  if (!rep) throw new Error('No Representation in AdaptationSet');

  const repId = rep.getAttribute('id') || '1';
  const bandwidth = +rep.getAttribute('bandwidth') || 0;
  const resolution = rep.getAttribute('width') && rep.getAttribute('height')
    ? `${rep.getAttribute('width')}x${rep.getAttribute('height')}`
    : null;

  const repBase = baseChain(rep);

  // Strategy 1: SegmentTemplate (most common modern DASH).
  const tmpl = rep.querySelector(':scope > SegmentTemplate') ||
               chosen.querySelector(':scope > SegmentTemplate');

  function fillTemplate(t, vars) {
    return t.replace(/\$(RepresentationID|Number|Time|Bandwidth)(%0(\d+)d)?\$/g, (_, key, _w, pad) => {
      let v = vars[key];
      if (v === undefined) return '';
      if (pad) v = String(v).padStart(parseInt(pad), '0');
      return String(v);
    });
  }

  if (tmpl) {
    const segments = [];
    const initTpl = tmpl.getAttribute('initialization');
    const mediaTpl = tmpl.getAttribute('media');
    const timescale = +tmpl.getAttribute('timescale') || 1;
    const duration  = +tmpl.getAttribute('duration')  || 0;
    const startNumber = +tmpl.getAttribute('startNumber') || 1;

    const initSegment = initTpl
      ? resolveUrl(repBase, fillTemplate(initTpl, { RepresentationID: repId, Bandwidth: bandwidth }))
      : null;

    // SegmentTimeline overrides duration math.
    const timeline = tmpl.querySelector('SegmentTimeline');
    if (timeline) {
      let time = 0, segIdx = 0, n = startNumber;
      for (const S of timeline.querySelectorAll('S')) {
        if (S.hasAttribute('t')) time = +S.getAttribute('t');
        const d = +S.getAttribute('d');
        const r = +S.getAttribute('r') || 0;
        for (let i = 0; i <= r; i++) {
          const url = resolveUrl(repBase, fillTemplate(mediaTpl, {
            RepresentationID: repId, Number: n, Time: time, Bandwidth: bandwidth
          }));
          segments.push({ url, index: segIdx++, encrypted: false });
          time += d;
          n++;
        }
      }
      return { segments, initSegment, totalSegments: segments.length, container: 'fmp4', resolution, bandwidth };
    }

    // Number-based template with duration.
    if (mediaTpl && duration > 0 && totalDuration > 0) {
      const segDurSec = duration / timescale;
      const count = Math.ceil(totalDuration / segDurSec);
      for (let i = 0; i < count; i++) {
        const n = startNumber + i;
        const url = resolveUrl(repBase, fillTemplate(mediaTpl, {
          RepresentationID: repId, Number: n, Bandwidth: bandwidth
        }));
        segments.push({ url, index: i, encrypted: false });
      }
      return { segments, initSegment, totalSegments: segments.length, container: 'fmp4', resolution, bandwidth };
    }
  }

  // Strategy 2: SegmentList.
  const segList = rep.querySelector(':scope > SegmentList');
  if (segList) {
    const segments = [];
    const initUrl = segList.querySelector('Initialization')?.getAttribute('sourceURL');
    const initSegment = initUrl ? resolveUrl(repBase, initUrl) : null;
    Array.from(segList.querySelectorAll('SegmentURL')).forEach((s, i) => {
      const media = s.getAttribute('media');
      if (media) {
        segments.push({ url: resolveUrl(repBase, media), index: i, encrypted: false });
      }
    });
    return { segments, initSegment, totalSegments: segments.length, container: 'fmp4', resolution, bandwidth };
  }

  // Strategy 3: SegmentBase (single-file) — just download the whole rep URL.
  const base = rep.querySelector(':scope > BaseURL')?.textContent?.trim();
  if (base) {
    const url = resolveUrl(repBase, base);
    return {
      segments: [{ url, index: 0, encrypted: false }],
      initSegment: null,
      totalSegments: 1,
      container: 'fmp4',
      resolution, bandwidth
    };
  }

  throw new Error('Could not parse DASH manifest — unsupported structure.');
}

// ─── Parallel segment fetch ─────────────────────────────────────────────────
async function fetchAllSegments({ segments, signal, onSegment, onFail }) {
  const buffers = new Array(segments.length);
  let failedCount = 0;
  const maxFails = Math.max(3, Math.ceil(segments.length * 0.05));
  let i = 0;

  async function worker() {
    while (i < segments.length) {
      if (signal.aborted) return;
      const myIdx = i++;
      const seg = segments[myIdx];
      try {
        let buf = await fetchBuf(seg.url, signal);
        if (seg.encrypted && seg.keyUri) {
          const key = await getAesKey(seg.keyUri, signal);
          const iv = buildIV(seg.iv, seg.index);
          buf = await crypto.subtle.decrypt({ name: 'AES-CBC', iv }, key, buf);
        }
        buffers[myIdx] = buf;
        onSegment?.(myIdx, segments.length);
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        failedCount++;
        onFail?.(myIdx, e, failedCount);
        if (failedCount > maxFails) {
          throw new Error(`Too many segment failures (${failedCount}). Aborted.`);
        }
        // Mark as empty so concatenation skips it.
        buffers[myIdx] = new ArrayBuffer(0);
      }
    }
  }

  const workers = Array.from({ length: Math.min(PARALLEL, segments.length) }, worker);
  await Promise.all(workers);
  return { buffers, failedCount };
}

// ─── Main engine ────────────────────────────────────────────────────────────
async function downloadStream({ reqId, url, filename, streamType }) {
  const controller = new AbortController();
  activeControllers[reqId] = controller;
  const { signal } = controller;
  const send = (pct, stage, extra = {}) => prog(reqId, pct, stage, extra);

  try {
    send(0, 'Parsing manifest...');

    let parsed = streamType === 'HLS'
      ? await parseHLS(url, signal)
      : await parseDASH(url, signal);

    if (parsed.error) { send(0, '', { error: parsed.error, done: true }); return; }

    // Master playlist → resolve to best media playlist.
    let separateAudioUrl = null;
    let bestIsMuxed = true;
    if (parsed.masterStreams) {
      const list = parsed.masterStreams
        .map(s => `${s.resolution || '?'} (${Math.round(s.bandwidth / 1000)}kbps)${s.hasMuxedAudio ? '' : '+sepA'}`)
        .join(' · ');
      const best = parsed.masterStreams[0];
      const note = parsed.bestIsMuxed
        ? `best: ${best.resolution || 'highest bitrate'} (muxed audio ✓)`
        : `best: ${best.resolution || 'highest bitrate'} ⚠ video-only — audio is separate`;
      send(2, `${parsed.masterStreams.length} streams → ${note} | ${list}`);
      separateAudioUrl = parsed.separateAudioUrl;
      bestIsMuxed = parsed.bestIsMuxed;
      parsed = await parseHLS(parsed.bestUrl, signal);
      if (parsed.error) { send(0, '', { error: parsed.error, done: true }); return; }
    }

    const { segments, initSegment, container, encrypted } = parsed;
    if (!segments?.length) {
      send(0, '', { error: 'No segments found in manifest. The playlist may be empty or live-updating.', done: true });
      return;
    }

    const encNote = encrypted ? ' 🔓 AES-128' : '';
    const initNote = initSegment ? ' + init' : '';
    send(5, `Downloading ${segments.length} segments${initNote}${encNote} (×${PARALLEL} parallel)...`);

    // Fetch init segment first (if present).
    let initBuf = null;
    if (initSegment) {
      try {
        initBuf = await fetchBuf(initSegment, signal);
      } catch (e) {
        if (e.name === 'AbortError') {
          send(0, '', { error: 'Cancelled by user.', done: true, cancelled: true });
          return;
        }
        send(0, '', { error: `Init segment failed: ${e.message}`, done: true });
        return;
      }
    }

    // Parallel segment fetch with live progress.
    let lastReported = -1;
    let completed = 0;
    const { buffers, failedCount } = await fetchAllSegments({
      segments,
      signal,
      onSegment: () => {
        completed++;
        const pct = 5 + Math.floor(completed / segments.length * 82);
        if (pct !== lastReported || completed === segments.length) {
          lastReported = pct;
          send(pct, `Segment ${completed}/${segments.length}${encrypted ? ' 🔓' : ''}`);
        }
      }
    });

    if (signal.aborted) {
      send(0, '', { error: 'Cancelled by user.', done: true, cancelled: true });
      return;
    }

    send(90, 'Stitching...');

    // Combine: init segment first, then all media segments in order.
    const parts = initBuf ? [initBuf, ...buffers] : buffers;
    const totalBytes = parts.reduce((a, b) => a + b.byteLength, 0);
    const combined = new Uint8Array(totalBytes);
    let offset = 0;
    for (const buf of parts) {
      combined.set(new Uint8Array(buf), offset);
      offset += buf.byteLength;
    }

    send(96, 'Preparing download...');

    // Pick extension based on detected container.
    const ext = container === 'fmp4' ? '.mp4' : '.ts';
    const baseName = filename.replace(/\.[^.]+$/, '').replace(/[^\w\-. ]/g, '_') || 'video';
    const outName = baseName + (bestIsMuxed ? ext : '_VIDEO' + ext);
    const mimeType = container === 'fmp4' ? 'video/mp4' : 'video/mp2t';

    const blob = new Blob([combined], { type: mimeType });
    const blobUrl = URL.createObjectURL(blob);

    chrome.runtime.sendMessage({
      action: 'triggerDownload', blobUrl, filename: outName, reqId
    }).catch(()=>{});

    // Revoke after 2 mins (download has long since started).
    setTimeout(() => URL.revokeObjectURL(blobUrl), 120000);

    const sizeMB = (totalBytes / 1024 / 1024).toFixed(1);
    const fmt = container === 'fmp4' ? '.mp4 (fMP4)' : '.ts (MPEG-TS)';

    // v1.2: if the video stream had a separate audio rendition, fetch+stitch it too.
    // Save it as <name>_AUDIO.<ext>. User can mux externally (ffmpeg / VLC / mkvtoolnix).
    if (separateAudioUrl) {
      send(96, 'Video done — fetching separate audio track...');
      try {
        const audioParsed = await parseHLS(separateAudioUrl, signal);
        if (!audioParsed.error && audioParsed.segments?.length) {
          let audioInitBuf = null;
          if (audioParsed.initSegment) {
            try { audioInitBuf = await fetchBuf(audioParsed.initSegment, signal); } catch {}
          }
          const audioRes = await fetchAllSegments({
            segments: audioParsed.segments,
            signal,
            onSegment: () => {} // silent — main progress already shows 96-99
          });
          const aParts = audioInitBuf ? [audioInitBuf, ...audioRes.buffers] : audioRes.buffers;
          const aTotal = aParts.reduce((s, b) => s + b.byteLength, 0);
          const aCombined = new Uint8Array(aTotal);
          let aOff = 0;
          for (const buf of aParts) { aCombined.set(new Uint8Array(buf), aOff); aOff += buf.byteLength; }
          const aExt = audioParsed.container === 'fmp4' ? '.m4a' : '.aac';
          const aName = baseName + '_AUDIO' + aExt;
          const aBlob = new Blob([aCombined], { type: audioParsed.container === 'fmp4' ? 'audio/mp4' : 'audio/aac' });
          const aUrl = URL.createObjectURL(aBlob);
          chrome.runtime.sendMessage({
            action: 'triggerDownload', blobUrl: aUrl, filename: aName, reqId
          }).catch(()=>{});
          setTimeout(() => URL.revokeObjectURL(aUrl), 120000);
        }
      } catch (audErr) {
        console.warn('[VidSnatcher] separate audio download failed:', audErr);
      }
    }

    const sepNote = separateAudioUrl
      ? ' + audio track (separate file — mux with ffmpeg/VLC if needed)'
      : '';
    send(100, `Done! ${outName} · ${sizeMB} MB · ${fmt}${sepNote}${failedCount ? ` (${failedCount} segs skipped)` : ''}`, { done: true });

  } catch (e) {
    if (e.name === 'AbortError') {
      prog(reqId, 0, '', { error: 'Cancelled by user.', done: true, cancelled: true });
    } else {
      // v1.2: friendlier error categorization.
      const raw = e.message || String(e);
      let friendly = raw;
      if (raw.includes('HTTP 403'))      friendly = 'Server returned 403 — site may require login/referer that the extension can\'t supply.';
      else if (raw.includes('HTTP 404')) friendly = 'Segment 404 — the playlist may be live/expired. Refresh the page and re-scan.';
      else if (raw.includes('HTTP 5'))   friendly = `Server error: ${raw}. Try again in a minute.`;
      else if (raw.toLowerCase().includes('cors')) friendly = 'CORS blocked — the segment server doesn\'t allow cross-origin fetches.';
      else if (raw.includes('AES'))      friendly = `Encryption issue: ${raw}`;
      else if (raw.includes('parse'))    friendly = `Manifest parse failed: ${raw}. The file may not be a standard HLS/DASH stream.`;
      prog(reqId, 0, '', { error: friendly, done: true });
    }
  } finally {
    delete activeControllers[reqId];
  }
}

// ─── DIRECT DOWNLOAD (v1.2) ─────────────────────────────────────────────────
// Fetch the URL in offscreen, verify Content-Type is video, then download
// from a blob. This is the fix for the "MP4 saves as HTML" bug — the old
// path passed the URL straight to chrome.downloads.download, which happily
// saved whatever the server returned (HTML auth wall, embed page, etc.)
async function directDownload({ reqId, url, filename }) {
  const controller = new AbortController();
  activeControllers[reqId] = controller;
  const { signal } = controller;
  const send = (pct, stage, extra = {}) => prog(reqId, pct, stage, extra);

  try {
    send(2, 'Connecting...');
    const headRes = await fetch(url, { method: 'HEAD', credentials: 'omit', signal })
      .catch(() => null); // HEAD may not be allowed; we'll re-check on GET

    if (headRes) {
      const ct = (headRes.headers.get('content-type') || '').toLowerCase();
      if (ct && !ct.startsWith('video/') && !ct.startsWith('audio/') &&
          !ct.includes('octet-stream') && !ct.includes('mpegurl') && !ct.includes('dash+xml')) {
        // Likely HTML/JSON/auth page — bail before downloading garbage.
        send(0, '', {
          error: `URL doesn't return video (Content-Type: ${ct}). The video URL may be expired, require login, or be an embed page.`,
          done: true
        });
        return;
      }
    }

    send(8, 'Downloading...');
    const res = await fetch(url, { credentials: 'omit', signal });
    if (!res.ok) {
      send(0, '', { error: `HTTP ${res.status} ${res.statusText} — the URL may have expired or require auth.`, done: true });
      return;
    }

    // Verify Content-Type post-GET (some servers only set it correctly here).
    const ct = (res.headers.get('content-type') || '').toLowerCase();
    if (ct.includes('text/html') || ct.includes('application/json')) {
      send(0, '', { error: `Server returned ${ct} — not a video. The URL likely points to a player page, not the file.`, done: true });
      return;
    }

    // Stream the response so we can show progress on large files.
    const total = parseInt(res.headers.get('content-length') || '0', 10);
    const chunks = [];
    let received = 0;
    const reader = res.body.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (signal.aborted) { send(0, '', { error: 'Cancelled by user.', done: true, cancelled: true }); return; }
      chunks.push(value);
      received += value.byteLength;
      if (total > 0) {
        const pct = Math.min(95, 8 + Math.floor(received / total * 87));
        send(pct, `Downloaded ${(received / 1048576).toFixed(1)} / ${(total / 1048576).toFixed(1)} MB`);
      } else {
        send(50, `Downloaded ${(received / 1048576).toFixed(1)} MB`);
      }
    }

    send(96, 'Preparing download...');

    // Pick mime type & extension from Content-Type, fall back to filename hint.
    let mimeType = ct.split(';')[0] || 'video/mp4';
    let ext = '.mp4';
    if      (mimeType.includes('webm'))     ext = '.webm';
    else if (mimeType.includes('matroska')) ext = '.mkv';
    else if (mimeType.includes('quicktime'))ext = '.mov';
    else if (mimeType.includes('audio/'))   ext = mimeType.includes('mp4') ? '.m4a' : '.mp3';
    else {
      // Fall back to URL extension
      const m = url.split('?')[0].match(/\.([a-z0-9]{2,4})$/i);
      if (m) ext = '.' + m[1].toLowerCase();
    }
    const baseName = (filename || 'video').replace(/\.[^.]+$/, '').replace(/[^\w\-. ]/g, '_') || 'video';
    const outName = baseName + ext;

    const blob = new Blob(chunks, { type: mimeType });
    const blobUrl = URL.createObjectURL(blob);
    chrome.runtime.sendMessage({
      action: 'triggerDownload', blobUrl, filename: outName, reqId
    }).catch(()=>{});
    setTimeout(() => URL.revokeObjectURL(blobUrl), 120000);

    const sizeMB = (received / 1048576).toFixed(1);
    send(100, `Done! ${outName} · ${sizeMB} MB · ${mimeType}`, { done: true });

  } catch (e) {
    if (e.name === 'AbortError') {
      prog(reqId, 0, '', { error: 'Cancelled by user.', done: true, cancelled: true });
    } else {
      const raw = e.message || String(e);
      let friendly = raw;
      if (raw.includes('Failed to fetch'))       friendly = 'Network blocked — the site may require CORS, cookies, or referer the extension can\'t supply.';
      else if (raw.toLowerCase().includes('cors')) friendly = 'CORS blocked — the file server doesn\'t allow cross-origin fetches from extensions.';
      prog(reqId, 0, '', { error: friendly, done: true });
    }
  } finally {
    delete activeControllers[reqId];
  }
}

// ─── MSE BUFFER DOWNLOAD (v1.2) ─────────────────────────────────────────────
// When the page uses MediaSource and feeds bytes via appendBuffer (no URL),
// inject.js collects all the chunks and the popup can request a download.
// The chunks travel content.js → background → offscreen via message passing
// (or directly if small enough). For now we just wrap+blob+download.
async function mseBufferDownload({ reqId, chunks, mimeType, filename }) {
  try {
    prog(reqId, 50, 'Stitching MSE buffer...');
    const blob = new Blob(chunks, { type: mimeType || 'video/mp4' });
    const blobUrl = URL.createObjectURL(blob);
    const ext = (mimeType && mimeType.includes('webm')) ? '.webm' : '.mp4';
    const baseName = (filename || 'mse-capture').replace(/\.[^.]+$/, '').replace(/[^\w\-. ]/g, '_');
    chrome.runtime.sendMessage({
      action: 'triggerDownload', blobUrl, filename: baseName + ext, reqId
    }).catch(()=>{});
    setTimeout(() => URL.revokeObjectURL(blobUrl), 120000);
    const sizeMB = (blob.size / 1048576).toFixed(1);
    prog(reqId, 100, `Done! MSE capture · ${sizeMB} MB`, { done: true });
  } catch (e) {
    prog(reqId, 0, '', { error: 'MSE buffer stitch failed: ' + e.message, done: true });
  }
}

// ─── Message handler ────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === 'offscreen_startDownload') {
    downloadStream(msg).catch(e => {
      chrome.runtime.sendMessage({
        action: 'progressUpdate', reqId: msg.reqId,
        percent: 0, stage: '', error: e.message || String(e), done: true
      }).catch(()=>{});
    });
  }
  if (msg.action === 'offscreen_directDownload') {
    directDownload(msg).catch(e => {
      chrome.runtime.sendMessage({
        action: 'progressUpdate', reqId: msg.reqId,
        percent: 0, stage: '', error: e.message || String(e), done: true
      }).catch(()=>{});
    });
  }
  if (msg.action === 'offscreen_mseDownload') {
    mseBufferDownload(msg).catch(e => {
      chrome.runtime.sendMessage({
        action: 'progressUpdate', reqId: msg.reqId,
        percent: 0, stage: '', error: e.message || String(e), done: true
      }).catch(()=>{});
    });
  }
  if (msg.action === 'offscreen_cancel') {
    const ctrl = activeControllers[msg.reqId];
    if (ctrl) { ctrl.abort(); delete activeControllers[msg.reqId]; }
  }
});
