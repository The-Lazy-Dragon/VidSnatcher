// ─────────────────────────────────────────────────────────────────────────────
//  怠竜 VidSnatcher · content.js · v1.1.0
//  Bridges postMessage from inject.js (MAIN world) → background SW.
//  Also scans the DOM for <video> elements and direct <a> links.
// ─────────────────────────────────────────────────────────────────────────────
(() => {
  const BL = [
    'netflix.com','primevideo.com','amazon.com','disneyplus.com','hulu.com',
    'max.com','hbomax.com','peacocktv.com','paramountplus.com',
    'appletv.apple.com','crunchyroll.com','funimation.com','mubi.com',
    'curiositystream.com','discoveryplus.com','espnplus.com','starz.com',
    'showtime.com','mgmplus.com','hotstar.com','jiocinema.com','sonyliv.com',
    'zee5.com','tv.apple.com','nowtv.com','britbox.com','acorn.tv','shudder.com'
  ];

  function isBlocked() {
    try {
      const h = location.hostname.replace(/^www\./, '');
      return BL.some(d => h === d || h.endsWith('.' + d));
    } catch { return false; }
  }

  if (isBlocked()) return; // Don't do anything on blacklisted sites.

  const seen = new Set();

  function getFilenameFromUrl(url) {
    try {
      const name = new URL(url).pathname.split('/').pop().split('?')[0];
      return name.length > 2 ? name : 'video';
    } catch { return 'video'; }
  }

  function getTypeFromUrl(url) {
    if (url.startsWith('mse-capture://')) return 'MSE-CAPTURE'; // v1.2: capturable
    if (url.startsWith('mediasource://')) return 'MediaSource';
    if (url.startsWith('blob:')) return 'Blob';
    try {
      const path = new URL(url).pathname.toLowerCase().split('?')[0];
      if (path.endsWith('.m3u8') || path.endsWith('.m3u')) return 'HLS';
      if (path.endsWith('.mpd')) return 'DASH';
      if (path.endsWith('.ts') || path.endsWith('.m4s')) return 'TS Segment';
      return (path.split('.').pop() || 'VIDEO').toUpperCase();
    } catch { return 'VIDEO'; }
  }

  function reportVideo(video) {
    if (!video?.url || seen.has(video.url)) return;
    // Block individual HLS segments — the m3u8 manifest is the real find.
    const lowerPath = (() => {
      try { return new URL(video.url).pathname.toLowerCase(); }
      catch { return video.url.toLowerCase(); }
    })();
    const isSegment = /\.(ts|m4s|aac)(\?.*)?$/i.test(lowerPath);
    if (isSegment && video.source !== 'dom') return;
    seen.add(video.url);
    chrome.runtime.sendMessage({ action: 'domVideos', videos: [video] }).catch(() => {});
  }

  // ─── Listen for inject.js postMessages ──────────────────────────────────
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (!event.data || !event.data.__vidsnatcher) return;
    const { url, source, mimeType, contentType, note } = event.data;
    if (!url) return;

    const type = getTypeFromUrl(url);
    const isStream = type === 'HLS' || type === 'DASH';
    const isMseCapture = url.startsWith('mse-capture://');
    // v1.2: mse-capture is its own special type — downloadable via the in-page buffer.
    const isBlob = !isMseCapture && (url.startsWith('blob:') || url.startsWith('mediasource://'));

    reportVideo({
      url, type, isStream, isBlob,
      mimeType: mimeType || contentType || null,
      filename: getFilenameFromUrl(url),
      source,
      note: note || null,
      timestamp: Date.now()
    });
  });

  // ─── DOM scanner ─────────────────────────────────────────────────────────
  function scanDOM() {
    document.querySelectorAll('video, audio').forEach(v => {
      const urls = [v.src, v.currentSrc, ...Array.from(v.querySelectorAll('source')).map(s => s.src)]
        .filter(Boolean);
      urls.forEach(url => {
        if (url.startsWith('blob:') || url.startsWith('http')) {
          const type = getTypeFromUrl(url);
          reportVideo({
            url, type,
            isStream: type === 'HLS' || type === 'DASH',
            isBlob: url.startsWith('blob:'),
            filename: getFilenameFromUrl(url),
            resolution: v.videoWidth ? `${v.videoWidth}x${v.videoHeight}` : null,
            duration: Number.isFinite(v.duration) ? v.duration : null,
            source: 'dom',
            timestamp: Date.now()
          });
        }
      });
    });

    document.querySelectorAll('a[href]').forEach(a => {
      const href = a.href || '';
      if (/\.(mp4|webm|mkv|mov|flv|avi|m3u8|mpd)(\?.*)?$/i.test(href)) {
        reportVideo({
          url: href,
          type: getTypeFromUrl(href),
          isStream: /\.(m3u8|mpd)/i.test(href),
          isBlob: false,
          filename: getFilenameFromUrl(href),
          source: 'link',
          timestamp: Date.now()
        });
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scanDOM, { once: true });
  } else {
    scanDOM();
  }

  // Watch for late-added <video> elements (most SPAs do this).
  const observer = new MutationObserver(() => scanDOM());
  observer.observe(document.documentElement, {
    childList: true, subtree: true,
    attributes: true, attributeFilter: ['src']
  });

  // v1.2: bridge for MSE buffer extraction. Content script and inject.js run
  // in different JS realms, so we have to ping the page via postMessage,
  // it copies the captured chunks into the message, content script forwards
  // to background → offscreen.
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'scanNow') {
      scanDOM();
      sendResponse({ ok: true });
      return true;
    }
    if (msg.action === 'getMSECapture') {
      // Ask the page (inject.js exposes __vidsnatcherGetMSE on window).
      const reqTag = 'vsn_mse_' + Date.now();
      const handler = (ev) => {
        if (ev.source !== window) return;
        if (!ev.data || ev.data.__vidsnatcherMSEReply !== reqTag) return;
        window.removeEventListener('message', handler);
        // ev.data has { buffers: [Uint8Array...], totalBytes, mimeType }
        sendResponse({
          ok: true,
          buffers: ev.data.buffers,
          totalBytes: ev.data.totalBytes,
          mimeType: ev.data.mimeType
        });
      };
      window.addEventListener('message', handler);
      // Forward request to MAIN world.
      window.postMessage({ __vidsnatcherMSERequest: reqTag }, '*');
      // Timeout in 3s
      setTimeout(() => {
        window.removeEventListener('message', handler);
        try { sendResponse({ ok: false, error: 'No MSE capture available' }); } catch {}
      }, 3000);
      return true; // async
    }
  });
})();
